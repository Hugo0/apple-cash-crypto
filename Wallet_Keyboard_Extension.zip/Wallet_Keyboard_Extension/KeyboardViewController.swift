//
//  KeyboardViewController.swift
//  Wallet_Keyboard_Extension
//
//  Created by GianluK on 8/23/24.
//

import UIKit

class KeyboardViewController: UIInputViewController {

    @IBOutlet var increaseButton: UIButton!
    @IBOutlet var decreaseButton: UIButton!
    @IBOutlet var amountLabel: UILabel!
    @IBOutlet var sendButton: UIButton!
    @IBOutlet var requestButton: UIButton!
    @IBOutlet var blockchainPicker: UIPickerView!
    @IBOutlet var blockchainButton: UIButton!
    
    var currentAmount: Int = 1
    
    // Queue of links to be sent
    var linkQueue: [String] = [
        "https://peanut.to/claim?c=5000&v=v4.3&i=460703&t=ui#p=FWxHy5fd3mBfb9c8",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460704&t=ui#p=Y6T4E5Cyf2w1I6Dh",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460705&t=ui#p=truZq1ZHnvNFzIHT",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460706&t=ui#p=kIAl3R8NB4Q7pX2E",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460707&t=ui#p=7EwDjDRt2n1DvAWN",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460708&t=ui#p=Aoq4x83Tbqt8acho",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460709&t=ui#p=o4FjKOX7AaSzmEXp",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460710&t=ui#p=3ecoyk2iTBQ2QQqr",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460711&t=ui#p=VqPzsCFGBNNvx8d2",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460712&t=ui#p=89b6fHgotM3cpfVv",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460713&t=ui#p=7UGFnqRalEoHZ4zn",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460714&t=ui#p=XfAx3M6Zzr0LsG21",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460715&t=ui#p=afmFfKIcvGyaJJOn",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460716&t=ui#p=X4Tl4vEF4QSUY5XO",
        "https://peanut.to/claim?c=5000&v=v4.3&i=460717&t=ui#p=Oogb1rg5ZfIrXsIv"
    ]
    
    // List of blockchains
    let blockchains = ["Polygon", "Avalanche", "Arbitrum", "Solana"]
    var selectedBlockchain = "Polygon"
    
    // Loading spinner
    var loadingSpinner: UIActivityIndicatorView!
    
    override func updateViewConstraints() {
        super.updateViewConstraints()
        // Add custom view sizing constraints here
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Create and setup the amount label
        amountLabel = UILabel()
        amountLabel.text = "$1"
        amountLabel.font = UIFont.systemFont(ofSize: 36)
        amountLabel.textAlignment = .center
        amountLabel.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(amountLabel)
        
        // Create and setup the increase button
        increaseButton = UIButton(type: .system)
        increaseButton.setTitle("+", for: [])
        increaseButton.titleLabel?.font = UIFont.systemFont(ofSize: 36)
        increaseButton.translatesAutoresizingMaskIntoConstraints = false
        increaseButton.addTarget(self, action: #selector(increaseAmount), for: .touchUpInside)
        self.view.addSubview(increaseButton)
        
        // Create and setup the decrease button
        decreaseButton = UIButton(type: .system)
        decreaseButton.setTitle("-", for: [])
        decreaseButton.titleLabel?.font = UIFont.systemFont(ofSize: 36)
        decreaseButton.translatesAutoresizingMaskIntoConstraints = false
        decreaseButton.addTarget(self, action: #selector(decreaseAmount), for: .touchUpInside)
        self.view.addSubview(decreaseButton)
        
        // Create and setup the request button
        requestButton = UIButton(type: .system)
        requestButton.setTitle("Request", for: [])
        requestButton.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        requestButton.translatesAutoresizingMaskIntoConstraints = false
        requestButton.addTarget(self, action: #selector(requestAmount), for: .touchUpInside)
        self.view.addSubview(requestButton)
        
        // Create and setup the send button
        sendButton = UIButton(type: .system)
        sendButton.setTitle("Send", for: [])
        sendButton.titleLabel?.font = UIFont.systemFont(ofSize: 24)
        sendButton.translatesAutoresizingMaskIntoConstraints = false
        sendButton.addTarget(self, action: #selector(sendAmount), for: .touchUpInside)
        self.view.addSubview(sendButton)
        
        // Create and setup the loading spinner
        loadingSpinner = UIActivityIndicatorView(style: .medium)
        loadingSpinner.translatesAutoresizingMaskIntoConstraints = false
        loadingSpinner.hidesWhenStopped = true
        self.view.addSubview(loadingSpinner)
        
        // Set up constraints
        setupConstraints()
    }
    
    func setupConstraints() {
        // Center the amount label
        amountLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        amountLabel.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        // Place the increase button to the right of the amount label
        increaseButton.leftAnchor.constraint(equalTo: amountLabel.rightAnchor, constant: 20).isActive = true
        increaseButton.centerYAnchor.constraint(equalTo: amountLabel.centerYAnchor).isActive = true
        
        // Place the decrease button to the left of the amount label
        decreaseButton.rightAnchor.constraint(equalTo: amountLabel.leftAnchor, constant: -20).isActive = true
        decreaseButton.centerYAnchor.constraint(equalTo: amountLabel.centerYAnchor).isActive = true
        
        // Place the request button below the amount label
        requestButton.topAnchor.constraint(equalTo: amountLabel.bottomAnchor, constant: 40).isActive = true
        requestButton.leftAnchor.constraint(equalTo: self.view.centerXAnchor, constant: -100).isActive = true
        
        // Place the send button next to the request button
        sendButton.topAnchor.constraint(equalTo: amountLabel.bottomAnchor, constant: 40).isActive = true
        sendButton.leftAnchor.constraint(equalTo: self.view.centerXAnchor, constant: 20).isActive = true
        
        // Place the loading spinner in the center of the view
        loadingSpinner.topAnchor.constraint(equalTo: amountLabel.bottomAnchor, constant: 40).isActive = true
        loadingSpinner.leftAnchor.constraint(equalTo: self.view.centerXAnchor, constant: 20).isActive = true
    }
    
    @objc func increaseAmount() {
        currentAmount += 1
        updateAmountLabel()
    }
    
    @objc func decreaseAmount() {
        if currentAmount > 1 {
            currentAmount -= 1
        }
        updateAmountLabel()
    }
    
    func updateAmountLabel() {
        amountLabel.text = "$\(currentAmount)"
    }
    
    @objc func sendAmount() {
        if !linkQueue.isEmpty {
            let link = linkQueue.removeFirst()
            
            // Disable the send button and start the loading spinner
            sendButton.isEnabled = false
            sendButton.setTitle("", for: .normal)
            loadingSpinner.startAnimating()
            
            // Add a 3-second delay before inserting the link
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { [weak self] in
                guard let self = self else { return }
                
                // Stop the loading spinner and re-enable the send button
                self.loadingSpinner.stopAnimating()
                self.sendButton.setTitle("Send", for: .normal)
                self.sendButton.isEnabled = true
                
                let proxy = self.textDocumentProxy as UITextDocumentProxy
                proxy.insertText(link)
            }
        } else {
            let proxy = textDocumentProxy as UITextDocumentProxy
            proxy.insertText("No more links available.")
        }
    }
    
    @objc func requestAmount() {
        let formattedAmount = formatAmount(currentAmount)
        let link = "https://amanu.app/claim/request?rea=0xd1387901E75B5Af2E4A68Da880D2485796c82d8C&amt=\(formattedAmount)"
        let proxy = textDocumentProxy as UITextDocumentProxy
        proxy.insertText(link)
    }
    
    func formatAmount(_ amount: Int) -> String {
        return String(amount * 1000000) // Multiply by 1,000,000 to get the correct amount in the URL
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }
    
    override func textWillChange(_ textInput: UITextInput?) {
        // The app is about to change the document's contents. Perform any preparation here.
    }
    
    override func textDidChange(_ textInput: UITextInput?) {
        // The app has just changed the document's contents, the document context has been updated.
    }
}
